package com.example.carracing3d

import com.badlogic.gdx.ApplicationAdapter
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.InputAdapter
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.PerspectiveCamera
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.VertexAttributes
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g3d.Environment
import com.badlogic.gdx.graphics.g3d.Model
import com.badlogic.gdx.graphics.g3d.ModelBatch
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3
import kotlin.random.Random

/** Upgraded 3D endless racer: menu, traffic, coins, nitro, scenery and saved high score. */
class RacingGame : ApplicationAdapter() {
    private enum class GameState { MENU, PLAYING, PAUSED, GAME_OVER }

    private lateinit var camera: PerspectiveCamera
    private lateinit var modelBatch: ModelBatch
    private lateinit var environment: Environment
    private lateinit var hudBatch: SpriteBatch
    private lateinit var font: BitmapFont
    private lateinit var pixel: Texture

    private lateinit var roadModel: Model
    private lateinit var groundModel: Model
    private lateinit var stripeModel: Model
    private lateinit var railModel: Model
    private lateinit var playerBodyModel: Model
    private lateinit var playerCabinModel: Model
    private lateinit var wheelModel: Model
    private lateinit var obstacleCabinModel: Model
    private lateinit var coinModel: Model
    private lateinit var treeTrunkModel: Model
    private lateinit var treeTopModel: Model
    private lateinit var buildingModels: List<Model>
    private lateinit var lampPoleModel: Model
    private lateinit var lampHeadModel: Model
    private lateinit var obstacleBodyModels: List<Model>

    private lateinit var road: ModelInstance
    private lateinit var ground: ModelInstance
    private lateinit var rails: List<ModelInstance>
    private lateinit var laneMarks: List<ModelInstance>
    private lateinit var playerParts: MutableList<ModelInstance>
    private val obstacles = mutableListOf<Obstacle>()
    private val coins = mutableListOf<Coin>()
    private val decorations = mutableListOf<Decoration>()

    private var state = GameState.MENU
    private var playerX = 0f
    private var speed = 22f
    private var score = 0
    private var highScore = 0
    private var coinCount = 0
    private var nitroFuel = 100f
    private var scoreProgress = 0f
    private var elapsed = 0f
    private var leftPressed = false
    private var rightPressed = false
    private var gasPressed = false
    private var nitroPressed = false

    private val lanePositions = floatArrayOf(-3.0f, 0f, 3.0f)
    private val wheelOffsets = listOf(
        Pair(-0.88f, -0.92f), Pair(0.88f, -0.92f),
        Pair(-0.88f, 0.92f), Pair(0.88f, 0.92f)
    )
    private val preferences by lazy { Gdx.app.getPreferences("speed-racer-scores") }

    private data class Obstacle(var parts: MutableList<ModelInstance>, var x: Float, var z: Float)
    private data class Coin(val instance: ModelInstance, var x: Float, var z: Float)
    private data class Decoration(
        val parts: MutableList<ModelInstance>,
        var x: Float,
        var z: Float,
        val kind: Int
    )

    override fun create() {
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST)
        Gdx.gl.glEnable(GL20.GL_BLEND)
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)

        camera = PerspectiveCamera(67f, Gdx.graphics.width.toFloat(), Gdx.graphics.height.toFloat())
        camera.near = 0.1f
        camera.far = 260f
        updateCamera()

        modelBatch = ModelBatch()
        hudBatch = SpriteBatch()
        font = BitmapFont().apply { data.setScale(1.25f) }
        pixel = makePixelTexture()
        highScore = preferences.getInteger("highScore", 0)

        environment = Environment().apply {
            set(ColorAttribute(ColorAttribute.AmbientLight, 0.72f, 0.72f, 0.76f, 1f))
            add(DirectionalLight().set(0.95f, 0.9f, 0.82f, -0.5f, -1f, -0.25f))
        }

        createModels()
        createWorld()
        createObstacles()
        createCoins()
        createDecorations()
        setupInput()
    }

    private fun makePixelTexture(): Texture {
        val pixmap = Pixmap(1, 1, Pixmap.Format.RGBA8888)
        pixmap.setColor(Color.WHITE)
        pixmap.fill()
        val texture = Texture(pixmap)
        pixmap.dispose()
        return texture
    }

    private fun createModels() {
        val builder = ModelBuilder()
        val attrs = (VertexAttributes.Usage.Position or VertexAttributes.Usage.Normal).toLong()
        roadModel = builder.createBox(10f, 0.22f, 180f, MaterialFactory.diffuse(Color(0.14f, 0.15f, 0.18f, 1f)), attrs)
        groundModel = builder.createBox(260f, 0.25f, 260f, MaterialFactory.diffuse(Color(0.12f, 0.34f, 0.16f, 1f)), attrs)
        stripeModel = builder.createBox(0.13f, 0.035f, 3.6f, MaterialFactory.diffuse(Color(1f, 0.88f, 0.35f, 1f)), attrs)
        railModel = builder.createBox(0.22f, 0.7f, 180f, MaterialFactory.diffuse(Color(0.62f, 0.66f, 0.7f, 1f)), attrs)
        playerBodyModel = builder.createBox(1.65f, 0.62f, 3.0f, MaterialFactory.diffuse(Color(0.88f, 0.035f, 0.025f, 1f)), attrs)
        playerCabinModel = builder.createBox(1.18f, 0.68f, 1.45f, MaterialFactory.diffuse(Color(0.06f, 0.16f, 0.23f, 1f)), attrs)
        wheelModel = builder.createCylinder(0.62f, 0.28f, 0.62f, 18, MaterialFactory.diffuse(Color(0.035f, 0.035f, 0.04f, 1f)), attrs)
        obstacleBodyModels = listOf(
            builder.createBox(1.65f, 0.62f, 3.0f, MaterialFactory.diffuse(Color(0.05f, 0.3f, 0.88f, 1f)), attrs),
            builder.createBox(1.65f, 0.62f, 3.0f, MaterialFactory.diffuse(Color(0.95f, 0.62f, 0.035f, 1f)), attrs),
            builder.createBox(1.65f, 0.62f, 3.0f, MaterialFactory.diffuse(Color(0.12f, 0.65f, 0.28f, 1f)), attrs)
        )
        obstacleCabinModel = builder.createBox(1.18f, 0.68f, 1.45f, MaterialFactory.diffuse(Color(0.1f, 0.13f, 0.17f, 1f)), attrs)
        coinModel = builder.createSphere(0.78f, 0.78f, 0.22f, 16, 12, MaterialFactory.diffuse(Color(1f, 0.72f, 0.04f, 1f)), attrs)
        treeTrunkModel = builder.createCylinder(0.48f, 1.8f, 0.48f, 10, MaterialFactory.diffuse(Color(0.34f, 0.18f, 0.08f, 1f)), attrs)
        treeTopModel = builder.createSphere(2.8f, 2.8f, 2.8f, 12, 10, MaterialFactory.diffuse(Color(0.08f, 0.42f, 0.13f, 1f)), attrs)
        buildingModels = listOf(
            builder.createBox(5.2f, 5.8f, 6f, MaterialFactory.diffuse(Color(0.48f, 0.52f, 0.59f, 1f)), attrs),
            builder.createBox(5.8f, 8f, 6.5f, MaterialFactory.diffuse(Color(0.58f, 0.42f, 0.3f, 1f)), attrs),
            builder.createBox(4.8f, 4.8f, 5.8f, MaterialFactory.diffuse(Color(0.38f, 0.48f, 0.55f, 1f)), attrs)
        )
        lampPoleModel = builder.createBox(0.16f, 5.2f, 0.16f, MaterialFactory.diffuse(Color(0.22f, 0.24f, 0.28f, 1f)), attrs)
        lampHeadModel = builder.createBox(0.8f, 0.18f, 0.34f, MaterialFactory.diffuse(Color(1f, 0.88f, 0.48f, 1f)), attrs)
    }

    private fun createWorld() {
        road = ModelInstance(roadModel).apply { transform.setToTranslation(0f, -0.02f, -65f) }
        ground = ModelInstance(groundModel).apply { transform.setToTranslation(0f, -0.24f, -65f) }
        rails = listOf(-5.15f, 5.15f).map { x ->
            ModelInstance(railModel).apply { transform.setToTranslation(x, 0.25f, -65f) }
        }
        val marks = mutableListOf<ModelInstance>()
        for (i in 0 until 22) {
            val z = 14f - i * 8.2f
            for (x in listOf(-1.65f, 1.65f)) {
                marks += ModelInstance(stripeModel).apply { transform.setToTranslation(x, 0.105f, z) }
            }
        }
        laneMarks = marks
        playerParts = buildCarParts(playerBodyModel, playerCabinModel, 0f, 0f)
    }

    private fun buildCarParts(body: Model, cabin: Model, x: Float, z: Float): MutableList<ModelInstance> {
        val parts = mutableListOf<ModelInstance>()
        parts += ModelInstance(body)
        parts += ModelInstance(cabin)
        repeat(4) { parts += ModelInstance(wheelModel) }
        updateCarPosition(parts, x, z)
        return parts
    }

    private fun updateCarPosition(parts: List<ModelInstance>, x: Float, z: Float) {
        if (parts.size < 6) return
        parts[0].transform.setToTranslation(x, 0.63f, z)
        parts[1].transform.setToTranslation(x, 1.25f, z - 0.12f)
        wheelOffsets.forEachIndexed { index, offset ->
            parts[index + 2].transform.setToTranslation(x + offset.first, 0.31f, z + offset.second)
            parts[index + 2].transform.rotate(Vector3.Z, 90f)
        }
    }

    private fun createObstacles() {
        obstacles.clear()
        repeat(6) { index ->
            val model = obstacleBodyModels[index % obstacleBodyModels.size]
            val x = lanePositions[Random.nextInt(lanePositions.size)]
            val z = -32f - index * 27f
            obstacles += Obstacle(buildCarParts(model, obstacleCabinModel, x, z), x, z)
        }
    }

    private fun createCoins() {
        coins.clear()
        repeat(5) { index ->
            val x = lanePositions[Random.nextInt(lanePositions.size)]
            val z = -42f - index * 37f
            val instance = ModelInstance(coinModel).apply { transform.setToTranslation(x, 1.1f, z) }
            coins += Coin(instance, x, z)
        }
    }

    private fun createDecorations() {
        decorations.clear()
        repeat(18) { index ->
            val kind = index % 3 // tree, building, street lamp
            val side = if (index % 2 == 0) -1f else 1f
            val x = side * when (kind) { 0 -> 8.5f; 1 -> 12.5f; else -> 7.2f }
            val z = 12f - (index / 2) * 19f
            val parts = when (kind) {
                0 -> mutableListOf(ModelInstance(treeTrunkModel), ModelInstance(treeTopModel))
                1 -> mutableListOf(ModelInstance(buildingModels[Random.nextInt(buildingModels.size)]))
                else -> mutableListOf(ModelInstance(lampPoleModel), ModelInstance(lampHeadModel))
            }
            decorations += Decoration(parts, x, z, kind)
            updateDecorationPosition(decorations.last())
        }
    }

    private fun updateDecorationPosition(item: Decoration) {
        when (item.kind) {
            0 -> {
                item.parts[0].transform.setToTranslation(item.x, 0.9f, item.z)
                item.parts[1].transform.setToTranslation(item.x, 2.55f, item.z)
            }
            1 -> item.parts[0].transform.setToTranslation(item.x, 2.9f, item.z)
            else -> {
                item.parts[0].transform.setToTranslation(item.x, 2.55f, item.z)
                item.parts[1].transform.setToTranslation(item.x - if (item.x < 0) -0.28f else 0.28f, 5.05f, item.z)
            }
        }
    }

    private fun setupInput() {
        Gdx.input.inputProcessor = object : InputAdapter() {
            override fun touchDown(screenX: Int, screenY: Int, pointer: Int, button: Int): Boolean {
                val yFromBottom = Gdx.graphics.height - screenY
                when (state) {
                    GameState.MENU -> { state = GameState.PLAYING; return true }
                    GameState.PAUSED -> { state = GameState.PLAYING; return true }
                    GameState.GAME_OVER -> { restartGame(); return true }
                    GameState.PLAYING -> Unit
                }
                if (yFromBottom > Gdx.graphics.height - 105f && screenX > Gdx.graphics.width - 150) {
                    state = GameState.PAUSED
                    clearControls()
                    return true
                }
                if (yFromBottom < 132f) {
                    when {
                        screenX in 22..134 -> leftPressed = true
                        screenX in 145..257 -> rightPressed = true
                        screenX in (Gdx.graphics.width - 285)..(Gdx.graphics.width - 160) -> gasPressed = true
                        screenX > Gdx.graphics.width - 145 -> nitroPressed = true
                    }
                }
                return true
            }

            override fun touchUp(screenX: Int, screenY: Int, pointer: Int, button: Int): Boolean {
                clearControls()
                return true
            }
        }
    }

    private fun clearControls() {
        leftPressed = false
        rightPressed = false
        gasPressed = false
        nitroPressed = false
    }

    override fun render() {
        val delta = Gdx.graphics.deltaTime.coerceAtMost(0.05f)
        if (state == GameState.PLAYING) updateGame(delta)

        Gdx.gl.glViewport(0, 0, Gdx.graphics.width, Gdx.graphics.height)
        Gdx.gl.glClearColor(0.42f, 0.68f, 0.88f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT or GL20.GL_DEPTH_BUFFER_BIT)

        updateCamera()
        modelBatch.begin(camera)
        modelBatch.render(ground, environment)
        modelBatch.render(road, environment)
        rails.forEach { modelBatch.render(it, environment) }
        laneMarks.forEach { modelBatch.render(it, environment) }
        decorations.forEach { item -> item.parts.forEach { modelBatch.render(it, environment) } }
        playerParts.forEach { modelBatch.render(it, environment) }
        obstacles.forEach { obstacle -> obstacle.parts.forEach { modelBatch.render(it, environment) } }
        coins.forEach { modelBatch.render(it.instance, environment) }
        modelBatch.end()
        drawHud()
    }

    private fun updateGame(delta: Float) {
        elapsed += delta
        val steering = 5.8f * delta
        if (leftPressed) playerX -= steering
        if (rightPressed) playerX += steering
        playerX = MathUtils.clamp(playerX, -3.55f, 3.55f)

        val usingNitro = nitroPressed && nitroFuel > 0f
        val targetSpeed = when {
            usingNitro -> 48f
            gasPressed -> 34f
            else -> 23f
        }
        speed = MathUtils.lerp(speed, targetSpeed + (elapsed * 0.12f).coerceAtMost(7f), delta * 1.7f)
        nitroFuel = if (usingNitro) (nitroFuel - delta * 32f).coerceAtLeast(0f)
        else (nitroFuel + delta * 8f).coerceAtMost(100f)

        scoreProgress += speed * delta * 0.45f
        score = scoreProgress.toInt()
        updateCarPosition(playerParts, playerX, 0f)

        laneMarks.forEach { mark ->
            mark.transform.translate(0f, 0f, speed * delta)
            if (mark.transform.getTranslation(Vector3()).z > 18f) mark.transform.setTranslation(mark.transform.getTranslation(Vector3()).x, 0.105f, -164f)
        }

        obstacles.forEach { obstacle ->
            obstacle.z += speed * delta
            if (obstacle.z > 8f) {
                obstacle.z = -145f - Random.nextFloat() * 55f
                obstacle.x = lanePositions[Random.nextInt(lanePositions.size)]
                val bodyModel = obstacleBodyModels[Random.nextInt(obstacleBodyModels.size)]
                obstacle.parts = buildCarParts(bodyModel, obstacleCabinModel, obstacle.x, obstacle.z)
            } else {
                updateCarPosition(obstacle.parts, obstacle.x, obstacle.z)
            }
            if (kotlin.math.abs(obstacle.z) < 2.2f && kotlin.math.abs(obstacle.x - playerX) < 1.45f) {
                finishGame()
            }
        }

        coins.forEach { coin ->
            coin.z += speed * delta
            coin.instance.transform.setTranslation(coin.x, 1.12f, coin.z)
            coin.instance.transform.rotate(Vector3.Y, 130f * delta)
            if (kotlin.math.abs(coin.z) < 1.7f && kotlin.math.abs(coin.x - playerX) < 1.45f) {
                coinCount++
                scoreProgress += 50f
                score += 50
                coin.z = -175f - Random.nextFloat() * 65f
                coin.x = lanePositions[Random.nextInt(lanePositions.size)]
            } else if (coin.z > 9f) {
                coin.z = -175f - Random.nextFloat() * 65f
                coin.x = lanePositions[Random.nextInt(lanePositions.size)]
            }
        }

        decorations.forEach { item ->
            item.z += speed * delta
            if (item.z > 24f) item.z = -165f - Random.nextFloat() * 55f
            updateDecorationPosition(item)
        }
    }

    private fun finishGame() {
        if (state != GameState.PLAYING) return
        state = GameState.GAME_OVER
        clearControls()
        if (score > highScore) {
            highScore = score
            preferences.putInteger("highScore", highScore)
            preferences.flush()
        }
    }

    private fun updateCamera() {
        camera.position.set(playerX * 0.25f, 7.2f, 13.5f)
        camera.lookAt(playerX * 0.18f, 0.4f, -11f)
        camera.up.set(Vector3.Y)
        camera.update()
    }

    private fun drawHud() {
        val width = Gdx.graphics.width.toFloat()
        val height = Gdx.graphics.height.toFloat()
        hudBatch.begin()
        when (state) {
            GameState.MENU -> drawMenu(width, height)
            GameState.PLAYING -> {
                drawRect(18f, height - 94f, 250f, 78f, Color(0f, 0f, 0f, 0.48f))
                font.color = Color.WHITE
                font.draw(hudBatch, "SCORE: $score", 32f, height - 30f)
                font.draw(hudBatch, "SPEED: ${speed.toInt()} km/h", 32f, height - 57f)
                font.draw(hudBatch, "COINS: $coinCount   BEST: $highScore", 32f, height - 82f)

                drawRect(width / 2f - 95f, height - 42f, 190f, 15f, Color(0f, 0f, 0f, 0.5f))
                drawRect(width / 2f - 92f, height - 39f, 184f * (nitroFuel / 100f), 9f, Color(0.1f, 0.65f, 1f, 1f))
                font.draw(hudBatch, "NITRO", width / 2f - 22f, height - 49f)

                drawButton(22f, 22f, 112f, 76f, "LEFT", Color(0.08f, 0.12f, 0.18f, 0.72f))
                drawButton(145f, 22f, 112f, 76f, "RIGHT", Color(0.08f, 0.12f, 0.18f, 0.72f))
                drawButton(width - 285f, 22f, 122f, 76f, "GAS", Color(0.08f, 0.42f, 0.16f, 0.82f))
                drawButton(width - 145f, 22f, 122f, 76f, "NITRO", Color(0.04f, 0.32f, 0.68f, 0.88f))
                drawButton(width - 112f, height - 68f, 90f, 46f, "PAUSE", Color(0.08f, 0.12f, 0.18f, 0.72f))
            }
            GameState.PAUSED -> drawOverlay(width, height, "PAUSED", "TAP TO CONTINUE")
            GameState.GAME_OVER -> {
                drawOverlay(width, height, "CRASH!", "TAP TO RACE AGAIN")
                font.data.setScale(1.3f)
                font.draw(hudBatch, "Score: $score     Coins: $coinCount", width / 2f - 115f, height / 2f - 24f)
                font.draw(hudBatch, "Best score: $highScore", width / 2f - 82f, height / 2f - 54f)
                font.data.setScale(1.25f)
            }
        }
        hudBatch.end()
    }

    private fun drawMenu(width: Float, height: Float) {
        drawRect(0f, 0f, width, height, Color(0f, 0f, 0f, 0.58f))
        font.color = Color(1f, 0.82f, 0.18f, 1f)
        font.data.setScale(2.6f)
        font.draw(hudBatch, "3D SPEED RACER", width / 2f - 175f, height / 2f + 78f)
        font.color = Color.WHITE
        font.data.setScale(1.35f)
        font.draw(hudBatch, "DODGE TRAFFIC  -  COLLECT COINS  -  USE NITRO", width / 2f - 220f, height / 2f + 25f)
        drawButton(width / 2f - 115f, height / 2f - 48f, 230f, 66f, "TAP TO START", Color(0.08f, 0.48f, 0.18f, 0.95f))
        font.data.setScale(1.2f)
        font.draw(hudBatch, "BEST SCORE: $highScore", width / 2f - 75f, height / 2f - 88f)
        font.data.setScale(1.25f)
    }

    private fun drawOverlay(width: Float, height: Float, title: String, subtitle: String) {
        drawRect(0f, 0f, width, height, Color(0f, 0f, 0f, 0.7f))
        font.color = Color.WHITE
        font.data.setScale(2.5f)
        font.draw(hudBatch, title, width / 2f - 90f, height / 2f + 45f)
        font.data.setScale(1.35f)
        font.draw(hudBatch, subtitle, width / 2f - 115f, height / 2f - 5f)
        font.data.setScale(1.25f)
    }

    private fun drawButton(x: Float, y: Float, w: Float, h: Float, label: String, color: Color) {
        drawRect(x, y, w, h, color)
        font.color = Color.WHITE
        font.draw(hudBatch, label, x + w * 0.2f, y + h * 0.58f)
    }

    private fun drawRect(x: Float, y: Float, w: Float, h: Float, color: Color) {
        hudBatch.color = color
        hudBatch.draw(pixel, x, y, w, h)
        hudBatch.color = Color.WHITE
    }

    private fun restartGame() {
        playerX = 0f
        speed = 22f
        score = 0
        coinCount = 0
        nitroFuel = 100f
        scoreProgress = 0f
        elapsed = 0f
        clearControls()
        createObstacles()
        createCoins()
        state = GameState.PLAYING
    }

    override fun resize(width: Int, height: Int) {
        if (::camera.isInitialized && width > 0 && height > 0) {
            camera.viewportWidth = width.toFloat()
            camera.viewportHeight = height.toFloat()
            camera.update()
        }
    }

    override fun dispose() {
        if (::modelBatch.isInitialized) modelBatch.dispose()
        if (::hudBatch.isInitialized) hudBatch.dispose()
        if (::font.isInitialized) font.dispose()
        if (::pixel.isInitialized) pixel.dispose()
        listOfNotNull(
            roadModel, groundModel, stripeModel, railModel, playerBodyModel, playerCabinModel,
            wheelModel, obstacleCabinModel, coinModel, treeTrunkModel, treeTopModel,
            lampPoleModel, lampHeadModel
        ).forEach { it.dispose() }
        if (::obstacleBodyModels.isInitialized) obstacleBodyModels.forEach { it.dispose() }
        if (::buildingModels.isInitialized) buildingModels.forEach { it.dispose() }
    }
}

private object MaterialFactory {
    fun diffuse(color: Color) = com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(color))
}
