extends Node3D

const LANES := [-3.0, 0.0, 3.0]
const CAR_FILES := ["res://assets/models/car_blue.obj", "res://assets/models/car_green.obj", "res://assets/models/car_yellow.obj"]
const ROAD_LENGTH := 190.0

var camera: Camera3D
var player: Node3D
var road_marks: Array[Node3D] = []
var scenery: Array[Node3D] = []
var traffic: Array[Node3D] = []
var coin_nodes: Array[Node3D] = []
var score_label: Label
var speed_label: Label
var nitro_bar: ProgressBar
var message_label: Label
var left_button: Button
var right_button: Button
var nitro_button: Button
var steer := 0.0
var speed := 28.0
var score := 0.0
var best_score := 0
var nitro := 100.0
var nitro_on := false
var spawn_clock := 0.0
var coin_clock := 0.0
var game_running := true
var game_over := false
var rng := RandomNumberGenerator.new()
var road_mat: StandardMaterial3D
var asphalt_mat: StandardMaterial3D
var glass_mat: StandardMaterial3D
var neon_mat: StandardMaterial3D
var car_mesh_cache: Dictionary = {}

func _ready() -> void:
    rng.randomize()
    _make_materials()
    _make_environment()
    _make_road()
    _make_city()
    _make_player()
    _make_camera()
    _make_ui()
    _load_best()
    _show_message("CITY RUSH  •  TAP TO RACE", 2.5)

func _make_materials() -> void:
    road_mat = StandardMaterial3D.new()
    road_mat.albedo_color = Color(0.075, 0.085, 0.105)
    road_mat.roughness = 0.88
    road_mat.metallic = 0.05
    asphalt_mat = StandardMaterial3D.new()
    asphalt_mat.albedo_color = Color(0.10, 0.31, 0.19)
    asphalt_mat.roughness = 1.0
    glass_mat = StandardMaterial3D.new()
    glass_mat.albedo_color = Color(0.08, 0.23, 0.34)
    glass_mat.metallic = 0.55
    glass_mat.roughness = 0.2
    glass_mat.emission_enabled = true
    glass_mat.emission = Color(0.02, 0.12, 0.22)
    neon_mat = StandardMaterial3D.new()
    neon_mat.albedo_color = Color(0.05, 0.75, 1.0)
    neon_mat.emission_enabled = true
    neon_mat.emission = Color(0.02, 0.42, 1.0)
    neon_mat.emission_energy_multiplier = 2.5

func _make_environment() -> void:
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.025, 0.08, 0.19)
    sky_mat.sky_horizon_color = Color(0.25, 0.43, 0.58)
    sky_mat.ground_bottom_color = Color(0.025, 0.035, 0.055)
    sky_mat.ground_horizon_color = Color(0.16, 0.22, 0.28)
    sky.sky_material = sky_mat
    env.sky = sky
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.tonemap_exposure = 1.05
    env.tonemap_white = 6.0
    env.glow_enabled = true
    env.glow_intensity = 0.35
    env.glow_strength = 0.8
    env.fog_enabled = true
    env.fog_light_color = Color(0.36, 0.48, 0.62)
    env.fog_density = 0.006
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.36, 0.43, 0.55)
    env.ambient_light_energy = 0.55
    world.environment = env
    add_child(world)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_color = Color(0.78, 0.86, 1.0)
    sun.light_energy = 1.35
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 85.0
    add_child(sun)

func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material, name := "Mesh") -> MeshInstance3D:
    var m := BoxMesh.new()
    m.size = size
    var inst := MeshInstance3D.new()
    inst.name = name
    inst.mesh = m
    inst.position = pos
    inst.material_override = mat
    parent.add_child(inst)
    return inst

func _make_road() -> void:
    var road := _box(self, Vector3(10.5, 0.25, ROAD_LENGTH), Vector3(0, -0.16, -78), road_mat, "Raceway")
    road.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    var ground_mat := StandardMaterial3D.new()
    ground_mat.albedo_color = Color(0.055, 0.105, 0.095)
    _box(self, Vector3(180, 0.3, ROAD_LENGTH), Vector3(0, -0.42, -78), ground_mat, "Ground")
    for side in [-1.0, 1.0]:
        _box(self, Vector3(0.18, 0.25, ROAD_LENGTH), Vector3(side * 5.2, 0.0, -78), neon_mat, "RoadEdge")
    for i in range(32):
        var z := 8.0 - float(i) * 5.8
        var lane_mat := StandardMaterial3D.new()
        lane_mat.albedo_color = Color(0.75, 0.84, 0.92)
        lane_mat.roughness = 0.65
        var mark := _box(self, Vector3(0.12, 0.025, 2.7), Vector3(0, 0.005, z), lane_mat, "LaneMark")
        road_marks.append(mark)

func _make_city() -> void:
    for i in range(20):
        var z := 12.0 - float(i) * 9.5
        for side in [-1.0, 1.0]:
            var h := rng.randf_range(9.0, 24.0)
            var w := rng.randf_range(5.0, 9.0)
            var d := rng.randf_range(5.0, 8.0)
            var building := Node3D.new()
            building.position = Vector3(side * rng.randf_range(10.5, 17.5), h * 0.5 - 0.25, z)
            add_child(building)
            var facade := StandardMaterial3D.new()
            var base := [Color(0.12,0.16,0.23), Color(0.18,0.20,0.25), Color(0.10,0.18,0.24), Color(0.22,0.18,0.16)][rng.randi_range(0,3)]
            facade.albedo_color = base
            facade.roughness = 0.72
            _box(building, Vector3(w, h, d), Vector3.ZERO, facade, "Tower")
            var floors := int(h / 3.0)
            for floor_i in range(floors):
                for col in range(2):
                    var x := (float(col) - 0.5) * w * 0.55
                    var win_mat := glass_mat.duplicate() as StandardMaterial3D
                    if rng.randf() < 0.28:
                        win_mat.albedo_color = Color(0.42,0.29,0.12)
                        win_mat.emission = Color(0.45,0.18,0.035)
                        win_mat.emission_energy_multiplier = 0.8
                    _box(building, Vector3(w * 0.19, 0.72, 0.045), Vector3(x, -h*0.5 + 1.2 + floor_i*2.6, d*0.5 + 0.026), win_mat, "Window")
            building.set_meta("loop_length", 190.0)
            scenery.append(building)
    for i in range(12):
        var lamp := Node3D.new()
        lamp.position = Vector3(-6.0 if i % 2 == 0 else 6.0, 0, 8.0 - i * 15.5)
        add_child(lamp)
        _box(lamp, Vector3(0.12, 5.5, 0.12), Vector3(0, 2.75, 0), glass_mat, "LampPost")
        _box(lamp, Vector3(1.5, 0.12, 0.12), Vector3(0.65 if i % 2 == 0 else -0.65, 5.45, 0), neon_mat, "LampArm")
        if i % 2 == 0:
            var glow := OmniLight3D.new()
            glow.position = Vector3(0.65 if i % 2 == 0 else -0.65, 5.25, 0)
            glow.light_color = Color(0.12, 0.55, 1.0)
            glow.light_energy = 0.8
            glow.omni_range = 7.0
            lamp.add_child(glow)
        lamp.set_meta("loop_length", 186.0)
        scenery.append(lamp)

func _load_car_mesh(path: String) -> Mesh:
    if car_mesh_cache.has(path):
        return car_mesh_cache[path]
    var loaded = load(path)
    if loaded is Mesh:
        car_mesh_cache[path] = loaded
        return loaded
    push_warning("Car mesh failed to import: " + path)
    return BoxMesh.new()

func _make_car(path: String, paint: Color) -> Node3D:
    var root := Node3D.new()
    var body := MeshInstance3D.new()
    body.mesh = _load_car_mesh(path)
    var paint_mat := StandardMaterial3D.new()
    paint_mat.albedo_color = paint
    paint_mat.metallic = 0.78
    paint_mat.roughness = 0.22
    paint_mat.clearcoat_enabled = true
    paint_mat.clearcoat = 0.8
    body.material_override = paint_mat
    root.add_child(body)
    var glass := StandardMaterial3D.new()
    glass.albedo_color = Color(0.025, 0.09, 0.15, 0.92)
    glass.metallic = 0.7
    glass.roughness = 0.12
    _box(root, Vector3(1.18, 0.48, 1.55), Vector3(0, 0.82, -0.15), glass, "CabinGlass")
    var tire_mat := StandardMaterial3D.new()
    tire_mat.albedo_color = Color(0.012,0.014,0.018)
    tire_mat.roughness = 0.95
    for x in [-0.88, 0.88]:
        for z in [-1.35, 1.35]:
            var tire := MeshInstance3D.new()
            var cyl := CylinderMesh.new()
            cyl.top_radius = 0.34
            cyl.bottom_radius = 0.34
            cyl.height = 0.22
            tire.mesh = cyl
            tire.rotation_degrees.z = 90
            tire.position = Vector3(x, 0.32, z)
            tire.material_override = tire_mat
            root.add_child(tire)
    var head_mat := StandardMaterial3D.new()
    head_mat.albedo_color = Color(0.75,0.9,1.0)
    head_mat.emission_enabled = true
    head_mat.emission = Color(0.55,0.8,1.0)
    head_mat.emission_energy_multiplier = 2.2
    for x in [-0.55,0.55]:
        _box(root, Vector3(0.3,0.12,0.08), Vector3(x,0.43,-2.02), head_mat, "Headlight")
    return root

func _make_player() -> void:
    player = _make_car("res://assets/models/car_red.obj", Color(0.82,0.035,0.045))
    player.position = Vector3(0, 0.08, 3.0)
    add_child(player)

func _make_camera() -> void:
    camera = Camera3D.new()
    camera.position = Vector3(0, 6.2, 12.5)
    camera.rotation_degrees = Vector3(-15, 0, 0)
    camera.fov = 72
    camera.current = true
    add_child(camera)

func _make_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var ui := Control.new()
    ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(ui)
    var panel := ColorRect.new()
    panel.color = Color(0.015,0.035,0.065,0.72)
    panel.position = Vector2(18,18)
    panel.size = Vector2(290,100)
    ui.add_child(panel)
    score_label = Label.new()
    score_label.position = Vector2(34,24)
    score_label.add_theme_font_size_override("font_size", 28)
    score_label.add_theme_color_override("font_color", Color(0.92,0.97,1))
    ui.add_child(score_label)
    speed_label = Label.new()
    speed_label.position = Vector2(34,67)
    speed_label.add_theme_font_size_override("font_size", 20)
    speed_label.add_theme_color_override("font_color", Color(0.25,0.8,1))
    ui.add_child(speed_label)
    nitro_bar = ProgressBar.new()
    nitro_bar.position = Vector2(18,132)
    nitro_bar.size = Vector2(290,18)
    nitro_bar.max_value = 100
    nitro_bar.show_percentage = false
    ui.add_child(nitro_bar)
    message_label = Label.new()
    message_label.anchor_left = 0.5
    message_label.anchor_top = 0.25
    message_label.anchor_right = 0.5
    message_label.offset_left = -360
    message_label.offset_right = 360
    message_label.offset_bottom = 65
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 32)
    message_label.add_theme_color_override("font_color", Color(0.9,0.97,1))
    ui.add_child(message_label)
    left_button = _add_button(ui, "◀", Vector2(28,-150), Vector2(118,100))
    right_button = _add_button(ui, "▶", Vector2(158,-150), Vector2(118,100))
    left_button.anchor_top = 1.0
    left_button.anchor_bottom = 1.0
    right_button.anchor_top = 1.0
    right_button.anchor_bottom = 1.0
    left_button.button_down.connect(_left_down)
    left_button.button_up.connect(_left_up)
    right_button.button_down.connect(_right_down)
    right_button.button_up.connect(_right_up)
    nitro_button = _add_button(ui, "NITRO", Vector2(-180,-145), Vector2(150,92))
    nitro_button.anchor_left = 1.0
    nitro_button.anchor_right = 1.0
    nitro_button.anchor_top = 1.0
    nitro_button.anchor_bottom = 1.0
    nitro_button.button_down.connect(func(): nitro_on = true)
    nitro_button.button_up.connect(func(): nitro_on = false)
    var pause := _add_button(ui, "Ⅱ", Vector2(-86,24), Vector2(64,58))
    pause.anchor_left = 1.0
    pause.anchor_right = 1.0
    pause.pressed.connect(_toggle_pause)
    var restart := _add_button(ui, "↻", Vector2(-160,24), Vector2(64,58))
    restart.anchor_left = 1.0
    restart.anchor_right = 1.0
    restart.pressed.connect(_restart)

func _left_down() -> void:
    steer = -1.0

func _left_up() -> void:
    if steer < 0.0:
        steer = 0.0

func _right_down() -> void:
    steer = 1.0

func _right_up() -> void:
    if steer > 0.0:
        steer = 0.0

func _add_button(parent: Control, caption: String, pos: Vector2, size: Vector2) -> Button:
    var b := Button.new()
    b.text = caption
    b.position = pos
    b.size = size
    b.add_theme_font_size_override("font_size", 26)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.025,0.11,0.19,0.82)
    style.border_color = Color(0.1,0.68,0.95,0.9)
    style.set_border_width_all(2)
    style.set_corner_radius_all(16)
    b.add_theme_stylebox_override("normal", style)
    var pressed := style.duplicate() as StyleBoxFlat
    pressed.bg_color = Color(0.04,0.3,0.43,0.95)
    b.add_theme_stylebox_override("pressed", pressed)
    parent.add_child(b)
    return b

func _process(delta: float) -> void:
    if not game_running or game_over:
        return
    var boost := nitro_on and nitro > 0.0
    if boost:
        nitro = maxf(0.0, nitro - delta * 25.0)
        speed = move_toward(speed, 49.0, delta * 15.0)
        camera.fov = lerpf(camera.fov, 82.0, delta * 3.0)
    else:
        nitro = minf(100.0, nitro + delta * 8.0)
        speed = move_toward(speed, 30.0, delta * 5.0)
        camera.fov = lerpf(camera.fov, 72.0, delta * 2.0)
    score += delta * speed * 0.8
    player.position.x = clampf(player.position.x + steer * delta * 8.0, -3.55, 3.55)
    player.rotation.z = lerpf(player.rotation.z, -steer * 0.12, delta * 6.0)
    camera.position.x = lerpf(camera.position.x, player.position.x * 0.32, delta * 2.5)
    for mark in road_marks:
        mark.position.z += speed * delta
        if mark.position.z > 13.0:
            mark.position.z -= 32.0 * 5.8
    for item in scenery:
        item.position.z += speed * delta
        if item.position.z > 24.0:
            item.position.z -= float(item.get_meta("loop_length", 190.0))
    spawn_clock += delta
    if spawn_clock > maxf(0.72, 1.65 - speed * 0.015):
        spawn_clock = 0.0
        _spawn_traffic()
    coin_clock += delta
    if coin_clock > 2.1:
        coin_clock = 0.0
        _spawn_coin()
    _move_traffic(delta)
    _move_coins(delta)
    score_label.text = "SCORE  %06d" % int(score)
    speed_label.text = "SPEED  %03d km/h   BEST %d" % [int(speed * 4.2), best_score]
    nitro_bar.value = nitro

func _spawn_traffic() -> void:
    var lane := LANES[rng.randi_range(0,2)]
    var colors := [Color(0.03,0.22,0.85), Color(0.04,0.62,0.28), Color(0.95,0.55,0.035)]
    var idx := rng.randi_range(0,2)
    var car := _make_car(CAR_FILES[idx], colors[idx])
    car.position = Vector3(lane, 0.08, -105.0)
    add_child(car)
    traffic.append(car)

func _spawn_coin() -> void:
    var coin := MeshInstance3D.new()
    var mesh := CylinderMesh.new()
    mesh.top_radius = 0.48
    mesh.bottom_radius = 0.48
    mesh.height = 0.12
    coin.mesh = mesh
    coin.rotation_degrees.x = 90
    coin.material_override = neon_mat
    coin.position = Vector3(LANES[rng.randi_range(0,2)], 1.0, -100.0)
    add_child(coin)
    coin_nodes.append(coin)

func _move_traffic(delta: float) -> void:
    for car in traffic.duplicate():
        car.position.z += (speed - 9.0) * delta
        car.rotate_y(delta * 0.08)
        if car.position.distance_to(player.position) < 2.2:
            _end_game()
            return
        if car.position.z > 18.0:
            traffic.erase(car)
            car.queue_free()

func _move_coins(delta: float) -> void:
    for coin in coin_nodes.duplicate():
        coin.position.z += speed * delta
        coin.rotate_y(delta * 2.4)
        if coin.position.distance_to(player.position + Vector3(0,0.8,0)) < 1.8:
            score += 150
            nitro = minf(100.0, nitro + 18.0)
            coin_nodes.erase(coin)
            coin.queue_free()
        elif coin.position.z > 16.0:
            coin_nodes.erase(coin)
            coin.queue_free()

func _show_message(text: String, seconds: float) -> void:
    message_label.text = text
    get_tree().create_timer(seconds).timeout.connect(_clear_message)

func _clear_message() -> void:
    if is_instance_valid(message_label):
        message_label.text = ""

func _end_game() -> void:
    game_over = true
    game_running = false
    best_score = maxi(best_score, int(score))
    _save_best()
    message_label.text = "CRASH!  SCORE %d  •  TAP RESTART" % int(score)

func _toggle_pause() -> void:
    if game_over:
        return
    game_running = not game_running
    message_label.text = "PAUSED" if not game_running else ""

func _restart() -> void:
    for car in traffic:
        car.queue_free()
    for coin in coin_nodes:
        coin.queue_free()
    traffic.clear()
    coin_nodes.clear()
    player.position = Vector3(0,0.08,3)
    player.rotation = Vector3.ZERO
    score = 0
    speed = 28
    nitro = 100
    spawn_clock = 0
    coin_clock = 0
    game_over = false
    game_running = true
    message_label.text = "GO!"
    get_tree().create_timer(1.0).timeout.connect(_clear_message)

func _save_best() -> void:
    var f := FileAccess.open("user://racer.save", FileAccess.WRITE)
    if f:
        f.store_32(best_score)

func _load_best() -> void:
    if FileAccess.file_exists("user://racer.save"):
        var f := FileAccess.open("user://racer.save", FileAccess.READ)
        if f:
            best_score = f.get_32()
